# Liste des couleurs possibles pour les cartes wagon
WAGON_COLORS = ['blue', 'yellow', 'green', 'red', 'violet', 'locomotive']

PLAYER_COLORS = ['white', 'black']
